import java.awt.*;

/**
 * Created by lb_k on 2/28/14.
 */
public class KdTree {
    private static class Node {
        Node left, right;
        int size = 0;
        Point2D p;
        private RectHV rect;

        Node(Point2D p, int size, RectHV rect) {
            this.p = p;
            this.size = size;
            this.left = this.right = null;
            this.rect = rect;
        }
    }
    private Node root;

    // construct an empty set of points
    public KdTree() {
        root = null;
    }

    // is the set empty?
    public boolean isEmpty() {
        return root == null;
    }

    // number of points in the set
    public int size() {
        if (root == null)
            return 0;
        else
            return root.size;
    }
    // add the point p to the set (if it is not already in the set)
    public void insert(Point2D p) {
        if (contains(p))
            return;

        Node root = this.root;
        int level = 0;

        if (root == null) { //first root
            this.root = new Node(p, 1, new RectHV(0., 0., 1., 1.));
            return;
        }

        RectHV rect = null;

        while (true) {
            root.size++;
            if (level % 2 == 0) {
                if (p.x() < root.p.x()) {
                    if (root.left != null)
                        root = root.left;
                    else {
                        rect = root.rect;
                        root.left = new Node(p, 1, new RectHV(rect.xmin(), rect.ymin(), root.p.x(), rect.ymax()));
                        break;
                    }
                }
                else {
                    if (root.right != null)
                        root = root.right;
                    else {
                        rect = root.rect;
                        root.right = new Node(p, 1, new RectHV(root.p.x(), rect.ymin(), rect.xmax(), rect.ymax()));
                        break;
                    }
                }
            }
            else if (level % 2 == 1) {
                if (p.y() < root.p.y()) {
                    if (root.left != null)
                        root = root.left;
                    else {
                        rect = root.rect;
                        root.left = new Node(p, 1, new RectHV(rect.xmin(), rect.ymin(), rect.xmax(), root.p.y()));
                        break;
                    }
                }
                else {
                    if (root.right != null)
                        root = root.right;
                    else {
                        rect = root.rect;
                        root.right = new Node(p, 1, new RectHV(rect.xmin(), root.p.y(), rect.xmax(), rect.ymax()));
                        break;
                    }
                }
            }
            level++;
        }
        //StdOut.println(level);
    }
    // does the set contain the point p?
    public boolean contains(Point2D p) {
        Node root = this.root;
        int level = 0;

        if (root == null) { //first root
            return false;
        }

        while (true) {
            if (root.p.equals(p))
                return true;

            if (level % 2 == 0) {
                if (p.x() < root.p.x()) {
                    if (root.left != null)
                        root = root.left;
                    else {
                        return false;
                    }
                }
                else {
                    if (root.right != null)
                        root = root.right;
                    else {
                        return false;
                    }
                }
            }
            else if (level % 2 == 1) {
                if (p.y() < root.p.y()) {
                    if (root.left != null)
                        root = root.left;
                    else {
                        return false;
                    }
                }
                else {
                    if (root.right != null)
                        root = root.right;
                    else {
                        return false;
                    }
                }
            }
            level++;
        }
    }
    // draw all of the points to standard draw
    public void draw() {
        draw(root, 0);
    }
    private void draw(Node root, int level) {
        if (root != null) {
            StdDraw.point(root.p.x(), root.p.y());
            StdDraw.setPenRadius(0.001);

            if (level % 2 == 0) {
                StdDraw.setPenColor(Color.red);
                StdDraw.line(root.p.x(), root.rect.ymin(), root.p.x(), root.rect.ymax());
            }
            else {
                StdDraw.setPenColor(Color.blue);
                StdDraw.line(root.rect.xmin(), root.p.y(), root.rect.xmax(), root.p.y());
            }

            StdDraw.setPenRadius(0.01);
            StdDraw.setPenColor(Color.black);
            draw(root.left , level+1);
            draw(root.right, level+1);
        }
    }

    // all points in the set that are inside the rectangle
    public Iterable<Point2D> range(RectHV rect) {
        Stack<Point2D> st = new Stack<Point2D>();
        range(rect, root, st);
        return st;
    }
    private void range(RectHV rect, Node root, Stack<Point2D> st) {
        if (root == null) return;
        if (root.rect.intersects(rect)) {
            if (rect.contains(root.p))
                st.push(root.p);
            range(rect, root.left, st);
            range(rect, root.right, st);
        }
    }

    // a nearest neighbor in the set to p; null if set is empty
    public Point2D nearest(Point2D p) {
        last = null;
        d = Double.POSITIVE_INFINITY;
        nearest(root, p, 0);
        return last;
    }

    private double d;
    private Point2D last;

    private void nearest(Node root, Point2D p, int level) {
        if (root == null) return;
        if (d < root.rect.distanceSquaredTo(p)) return;

        double tmp = root.p.distanceSquaredTo(p);
        if (tmp < d) {
            last = root.p;
            d = tmp;
        }

        if (level % 2 == 0) {
            if (p.x() < root.p.x()) {
                nearest(root.left , p, level+1);
                nearest(root.right, p, level+1);
            }
            else {
                nearest(root.right, p, level+1);
                nearest(root.left , p, level+1);
            }
        }
        else {
            if (p.y() < root.p.y()) {
                nearest(root.left , p, level+1);
                nearest(root.right, p, level+1);
            }
            else {
                nearest(root.right, p, level+1);
                nearest(root.left , p, level+1);
            }
        }
    }

    public static void main(String[] args) {
        StdDraw.setXscale(0, 1);
        StdDraw.setYscale(0, 1);
        StdDraw.setPenRadius(0.01);

        KdTree tr = new KdTree();
        tr.insert(new Point2D(0.7, 0.2));
        tr.insert(new Point2D(0.5, 0.4));
        tr.insert(new Point2D(0.2, 0.3));
        tr.insert(new Point2D(0.4, 0.7));
        tr.insert(new Point2D(0.9, 0.6));
        StdOut.println(tr.nearest(new Point2D(0.5, 0.5)));
        StdOut.println(tr.size());
        StdOut.println(tr.contains(new Point2D(0.2,0.3)));

        tr.draw();
    }
}
